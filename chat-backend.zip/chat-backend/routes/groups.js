const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Group = require('../models/Group');
const User = require('../models/User');

router.post('/', auth, async (req, res) => {
    try {
        const newGroup = new Group({
            name: req.body.name,
            admin: req.user.id,
            members: [req.user.id]
        });

        const group = await newGroup.save();

        await User.findByIdAndUpdate(req.user.id, { $push: { groups: group._id } });

        res.json(group);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

router.get('/', auth, async (req, res) => {
    try {
        const groups = await Group.find({ members: req.user.id });
        res.json(groups);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

module.exports = router;