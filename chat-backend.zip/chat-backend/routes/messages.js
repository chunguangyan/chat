const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Message = require('../models/Message');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname))
    }
});

const upload = multer({ storage: storage });

router.post('/', auth, upload.single('image'), async (req, res) => {
    try {
        const newMessage = new Message({
            sender: req.user.id,
            channel: req.body.channelId,
            type: req.file ? 'image' : 'text',
            content: req.body.content,
            imageUrl: req.file ? `/uploads/${req.file.filename}` : null
        });

        const message = await newMessage.save();
        res.json(message);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

router.get('/:channelId', auth, async (req, res) => {
    try {
        const messages = await Message.find({ channel: req.params.channelId }).sort({ timestamp: -1 }).limit(50);
        res.json(messages);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

module.exports = router;