const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json());

const JWT_SECRET = '123456';

// 连接到 MongoDB
mongoose.connect('mongodb://localhost:27017/chat')
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('Could not connect to MongoDB', err));



const Channel = mongoose.model('Channel', {
    name: String,
    description: String
});


const UserRole = {
    ADMIN: 'admin',
    MODERATOR: 'moderator',
    USER: 'user'
};

// 读取 JSON 文件
async function readJsonFile(filename) {
    const data = await fs.readFile(path.join(__dirname, filename), 'utf8');
    return JSON.parse(data);
}

// 写入 JSON 文件
async function writeJsonFile(filename, data) {
    await fs.writeFile(path.join(__dirname, filename), JSON.stringify(data, null, 2));
}


function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
}


function checkRole(role) {
    return (req, res, next) => {
        if (req.user.role !== role) {
            return res.status(403).json({ message: "Access denied" });
        }
        next();
    }
}

// 用户注册
app.post('/register', async (req, res) => {
    try {
        const { username, password } = req.body;
        const users = await readJsonFile('users.json');

        if (users.find(u => u.username === username)) {
            return res.status(400).json({ message: "Username already exists" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = {
            id: users.length + 1,
            username,
            password: hashedPassword,
            role: UserRole.USER
        };
        users.push(newUser);
        await writeJsonFile('users.json', users);

        res.status(201).json({ message: "User created successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error registering user" });
    }
});

// 用户登录
app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const users = await readJsonFile('users.json');
        const user = users.find(u => u.username === username);

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(400).json({ message: "Invalid username or password" });
        }

        const token = jwt.sign(
            { id: user.id, username: user.username, role: user.role },
            JWT_SECRET,
            { expiresIn: '1h' }
        );

        res.json({ token });
    } catch (error) {
        res.status(500).json({ message: "Error logging in" });
    }
});

// 获取所有用户（仅管理员）
app.get('/users', authenticateToken, checkRole(UserRole.ADMIN), async (req, res) => {
    try {
        const users = await readJsonFile('users.json');
        res.json(users.map(({ password, ...user }) => user));  // 不返回密码
    } catch (error) {
        res.status(500).json({ message: "Error fetching users" });
    }
});

// 创建新频道（管理员和版主）
app.post('/channels', authenticateToken, checkRole(UserRole.MODERATOR), async (req, res) => {
    try {
        const { name, description } = req.body;
        const channel = new Channel({ name, description });
        await channel.save();
        res.status(201).json(channel);
    } catch (error) {
        res.status(500).json({ message: "Error creating channel" });
    }
});

// 获取所有频道
app.get('/channels', authenticateToken, async (req, res) => {
    try {
        const channels = await Channel.find();
        res.json(channels);
    } catch (error) {
        res.status(500).json({ message: "Error fetching channels" });
    }
});


module.exports = app;  // 导出 app 以便其他文件可以使用