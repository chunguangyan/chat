const mongoose = require('mongoose');

const MessageSchema = new mongoose.Schema({
    sender: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    content: String,
    channel: { type: mongoose.Schema.Types.ObjectId, ref: 'Channel', required: true },
    timestamp: { type: Date, default: Date.now },
    type: { type: String, enum: ['text', 'image'], default: 'text' },
    imageUrl: String
});

module.exports = mongoose.model('Message', MessageSchema);