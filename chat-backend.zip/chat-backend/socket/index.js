const socketIo = require('socket.io');
const Message = require('../models/Message');

module.exports = function(server) {
    const io = socketIo(server);

    io.on('connection', (socket) => {
        console.log('New client connected');

        socket.on('join channel', (channelId) => {
            socket.join(channelId);
            console.log(`User joined channel: ${channelId}`);
        });

        socket.on('leave channel', (channelId) => {
            socket.leave(channelId);
            console.log(`User left channel: ${channelId}`);
        });

        socket.on('chat message', async (msg) => {
            try {
                const newMessage = new Message({
                    sender: msg.sender,
                    content: msg.content,
                    channel: msg.channelId
                });
                await newMessage.save();

                io.to(msg.channelId).emit('chat message', newMessage);
            } catch (error) {
                console.error('Error saving message:', error);
            }
        });

        socket.on('disconnect', () => {
            console.log('Client disconnected');
        });
    });
};