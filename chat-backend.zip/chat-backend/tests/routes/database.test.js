const mongoose = require('mongoose');
const sinon = require('sinon');
const chai = require('chai');
const expect = chai.expect;
const connectDB = require('../../config/database');

describe('Database Connection', () => {
    let mongooseConnectStub;

    beforeEach(() => {
        // 模拟成功的数据库连接
        mongooseConnectStub = sinon.stub(mongoose, 'connect').resolves({
            connection: { host: 'localhost' }
        });
    });

    afterEach(() => {
        // 恢复 stub
        mongooseConnectStub.restore();
    });


    it('should connect to the database successfully', async () => {
        await connectDB();
        expect(mongooseConnectStub.calledOnce).to.be.true;
        expect(mongooseConnectStub.firstCall.args[0]).to.equal('mongodb://localhost:27017/chat');
    });


    it.skip('should throw an error if connection fails', async () => {
        mongooseConnectStub.restore();
        mongooseConnectStub = sinon.stub(mongoose, 'connect').rejects(new Error('Connection failed'));

        try {
            await connectDB();
        } catch (error) {
            expect(error.message).to.equal('Connection failed');
        }
    });


    it('should verify the database URI', () => {
        const dbURI = 'mongodb://localhost:27017/chat';
        expect(dbURI).to.equal('mongodb://localhost:27017/chat');
    });


    it('should verify that the user object has a name property', () => {
        const user = { name: 'Alice', age: 25 };
        expect(user).to.have.property('name');
        expect(user.name).to.equal('Alice');
    });


    it.skip('should return true for boolean comparison', () => {
        const value = true;
        expect(value).to.be.true;
    });
});
