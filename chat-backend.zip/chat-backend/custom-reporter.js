const Mocha = require('mocha');

class CustomReporter extends Mocha.reporters.Spec {
    constructor(runner) {
        super(runner);
        let passes = 0;
        let failures = 0;

        runner.on('pass', function () {
            passes++;
        });

        runner.on('fail', function (test, err) {
            failures++;
            console.log(`Test failed: ${test.title}`);
            console.log(`Error: ${err.message}`);
            console.log(err.stack); // 打印详细错误堆栈
        });

        runner.on('end', function () {
            const total = passes + failures;
            const passPercentage = (passes / total) * 100;
            console.log(`\n${passes} passing`);
            console.log(`${failures} failing`);
            console.log(`Pass percentage: ${passPercentage.toFixed(2)}%`);
        });
    }
}

module.exports = CustomReporter;

